// Configuration file for FakeiOSVersion
// Change these values to fake different iOS versions

#define FAKE_IOS_VERSION @"17.2"
#define FAKE_IOS_BUILD @"21C52"
#define FAKE_DEVICE_MODEL @"iPhone15,2"
#define FAKE_USER_AGENT @"iOS/17.2"

// Supported iOS versions for reference:
// iOS 17.2: Build 21C52
// iOS 17.1: Build 21B74
// iOS 17.0: Build 21A329
// iOS 16.7: Build 20H19
// iOS 16.6: Build 20G75